# libavif man pages

This contains the man pages for `avifenc` and `avifdec`. These are written in
[pandoc's Markdown](https://pandoc.org/MANUAL.html#pandocs-markdown), so
[pandoc](https://pandoc.org/) is required to build these.

Building man pages is disabled by default. Enable the CMake option
`AVIF_BUILD_MAN_PAGES` to build these.
